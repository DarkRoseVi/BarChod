﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barcode.Componens
{
    class BdConect
    {
        public static CodeEntities bd = new CodeEntities();
    }
}
